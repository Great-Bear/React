import React from 'react';
import {NavLink} from 'react-router-dom'


const NotFound = () => (
    <h2>Resource not found</h2>
);

export default NotFound;
