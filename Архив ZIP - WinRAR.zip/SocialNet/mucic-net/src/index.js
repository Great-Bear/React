import React from 'react'
import ReactDOM from 'react-dom'

import About from './About'
import NotFound from './NotFound';
import UserPage from './UserPage'
import Signin from './Signin'
import 'bootstrap/dist/css/bootstrap.css';

import './css/index.css'
import {BrowserRouter, Route, Switch} from 'react-router-dom'

ReactDOM.render(
    <div>
       <BrowserRouter>
            <Switch>
                <Route exact path="/" component={()=> <Signin/> } />
                <Route path="/about" children={()=><h2> <About/> </h2>} />  
                <Route path="/UserPage/:id?" children={()=> <UserPage referrer={ "currentLocation"}/> }  />                           
                <Route component={NotFound} />
            </Switch>
        </BrowserRouter>
  
    </div>,
    document.getElementById('root')
)