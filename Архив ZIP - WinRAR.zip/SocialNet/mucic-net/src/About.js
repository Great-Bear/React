import React from 'react';


class About extends React.Component{
    render(){
        return <div>
                <p>We are best site for music</p>
        </div>
    }
}
export default About;