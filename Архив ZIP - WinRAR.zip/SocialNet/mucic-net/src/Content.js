import React from 'react'
import Post from './Post.js'

import './css/Content.css'

function Content(){
    return(
        <div id="content">
           <Post/>
           <Post/>
         </div>
    )
}

export default Content;